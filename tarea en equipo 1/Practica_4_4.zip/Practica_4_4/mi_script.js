document.addEventListener('DOMContentLoaded', function () {
    // Numero de enlaces de la pagina

    // Direccion del penultimo enlace

    // Numero de enlaces que apuntan a http://prueba

    // Numero de enlaces del tercer párrafo
});